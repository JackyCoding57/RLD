import matplotlib

matplotlib.use("TkAgg")
import gym
import ast
import gridworld
from gym import wrappers, logger
import numpy as np
import copy
import random as rd


# Creation de l'environnement
env = gym.make("gridworld-v0")
env.setPlan("gridworldPlans/plan0.txt", {0: -0.001, 3: 1, 4: 1, 5: -1, 6: -1})
statedic, mdp = env.getMDP()


# Initialisation de V
LV = []
states = [k for (k, val) in statedic.items()]
init_state = [k for (k, val) in statedic.items() if val == 0][0]

for state in states:
    val = int(init_state[state.index('2')])
    if val == 0:
        LV.append(0)
    if val == 2:
        LV.append(0)
    if val == 3:
        LV.append(1)
    if val == 4:
        LV.append(1)
    if val == 5:
        LV.append(-1)
    if val == 6:
        LV.append(-1)
print(LV)



# Value Iteration
gamma = 0.9
i, k = 0, 0
epsilon = 10e-7
old_LV = [10] * len(statedic)
Pol = []
old_Pol = [10] * len(statedic)
LVtemp = LV.copy()

for state in states:
    actions = mdp.get(state)
    if actions is not None:
        index = rd.choice(list(actions.keys()))
        Pol.append(actions.get(index))
    else :
        Pol.append(0)


states = [k for (k, val) in mdp.items()]

while old_Pol != Pol:
    while np.linalg.norm(np.array(LV)-np.array(old_LV)) >= epsilon:
        for state in states:
            state_index = statedic.get(state)
            action = Pol[state_index]
            Vi = 0
            for a in range(len(action)):
                Vs = action[a][1]
                Vindex = statedic.get(Vs)
                V = LV[Vindex]
                Vi += action[a][0] * (action[k][2] + gamma*V)

            old_LV = LV.copy()
            LVtemp[state_index] = Vi

        LV = LVtemp.copy()
        i += 1

    old_Pol = Pol.copy()
    for state in states:
        Vi = -99999999999
        actions = mdp.get(state)
        print(actions)
        state_index = statedic.get(state)
        for j in range(len(actions)):
            Via = 0
            action = actions.get(j)
            for a in range(len(action)):
                Vs = action[a][1]
                Vindex = statedic.get(Vs)
                V = LV[Vindex]
                Via += action[a][0] * (action[a][2] + gamma * V)
            if Via > Vi:
                Vi = Via
                Pol_i = action
        Pol[state_index] = Pol_i
    k += 1

print(k)
print(LV)
#print(statedic)
print(Pol)


for s in range(len(states)):
                if s in P:
                    maxlist = np.zeros(4)
                    for aprime in range(4):
                        for sprime in range(len(states)):
                            idx = np.where(np.array(P[s][aprime])[:, 1] == sprime)
                            if len(idx[0]) != 0:
                                idx = idx[0][0]
                                maxlist[aprime] += P[s][aprime][idx][0]*(P[s][aprime][idx][2] + gamma*self.V[sprime])
                    self.pi[s] = np.argmax(maxlist)

[0.5822966697368918, -1, 1.0011158211108437, 1.2059963271037581, 1.7893842509562314, 1, 1.5699471414762294, 1.3589469837935269, 1.1920010888189059, 1.0314635862149464, 0.9044298442805493]
[1.30725117 1.32833657 1.53559666 1.72171404 2.00848694 1.06934085
 1.68531274 1.52720598 1.25781552 1.17139844 1.26624848]

class ValueIteration:
    """Value Iteration Agent"""
    def __init__(self, action_space, epsilon=0.1, gamma=1):
        self.action_space = action_space
        states, P = env.getMDP()
        self.pi = np.zeros(len(states))
        self.V = np.random.uniform(0, 2, len(states))
        V = np.zeros(len(states))
        while np.linalg.norm(V - self.V) > epsilon:
            V = self.V.copy()
            for s in range(len(states)):
                if s in P:
                    maxlist = np.zeros(4)
                    for aprime in range(4):
                        for sprime in range(len(states)):
                            idx = np.where(np.array(P[s][aprime])[:, 1] == sprime)
                            if len(idx[0]) != 0:
                                idx = idx[0][0]
                                maxlist[aprime] += P[s][aprime][idx][0] * (P[s][aprime][idx][2] + gamma * self.V[sprime])
                    self.V[s] = np.max(maxlist)
            Vfirst = self.V.copy()
        for s in range(len(states)):
            if s in P:
                maxlist = np.zeros(4)
                for aprime in range(4):
                    for sprime in range(len(states)):
                        idx = np.where(np.array(P[s][aprime])[:, 1] == sprime)
                        if len(idx[0]) != 0:
                            idx = idx[0][0]
                            maxlist[aprime] += P[s][aprime][idx][0] * (P[s][aprime][idx][2] + gamma * self.V[sprime])
                self.pi[s] = np.argmax(maxlist)


    def act(self, obs):
        state = env.getStateFromObs(obs)
        return (self.pi[state])